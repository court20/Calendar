#include "day.h"
#include "event.h"
#include "user.h"
#include "sortAlg.cpp"
#include <string>
#include <iostream>

using namespace std;

int main(){
	day yes= day("monday");
}
