# Big Big Sorting Cool Calendar, pretty cool //really cool



<h2> <b>Plans for GUI</b> </h2>
<ul>
  <li> Use Qt</li>
  <li> Pages needed </li>
      <ul>
        <li> displaying the calendar</li>
        <li>splash Page "welcome to your calendar" </li>
        <li>pick to add event / add assignment</li>
        <li>actual form for putting information for event</li>
        <li>actual form for putting information for assignment</li>
       </ul>
</ul>
